<!doctype html>
<html lang="en" dir="ltr">

<!-- #Head -->

<head>

<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="author" content="Online Tutoring" />
<meta name="robots" content="index, follow" />

<!-- Links -->
	
<link rel="stylesheet" href="assets/fonts/gilda/gilda-font.css" />
<link rel="stylesheet" href="assets/fonts/roboto/roboto-font.css" />
<link rel="stylesheet" href="assets/plugins/bootstrap/bootstrap.min.css" />
<link rel="stylesheet" href="assets/plugins/bootstrap-datepicker/bootstrap-datetimepicker.min.css" />
<link rel="stylesheet" href="assets/plugins/sweetalert/sweetalert.css" />
<link rel="stylesheet" href="assets/css/style.min.css" />

<!-- Links End -->



<!-- #Social Media -->

<link rel="icon" href="assets/img/social/favicon.png" type="image/png" />

	
<!-- #Social Media End -->

<title>Online Tutoring</title>

	
</head>
	
<!-- End Head -->
