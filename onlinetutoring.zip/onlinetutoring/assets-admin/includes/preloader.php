<div class="preloader">
<div class="preloader-logo">
<img src="assets-admin/img/loader-logo.png" alt="LogiFort loader Logo" />
<h1>Seal The Deal</h1>
</div>
<div class="preloader-body">
<div class="loadingprogress"></div>
</div>
</div>

<div class="loading-cus" id="loadingDiv"><div class="loader-cus"></div></div>