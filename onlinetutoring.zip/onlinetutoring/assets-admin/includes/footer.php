<footer>
	
<div class="footer-copyright">
<div class="container-fluid">
<div class="row">	

<div class="col-lg-12 text-center">
<p>&copy;<span id="thisyear" class="mx-1"></span>OnlineTutoring.com<span class="mx-1">&reg;</span>All rights reserved</p>	
</div>
	
</div>
</div>
</div>
	
</footer>
